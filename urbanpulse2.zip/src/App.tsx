import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, 
  AlertTriangle, 
  Camera, 
  Car, 
  CheckCircle2, 
  ChevronRight, 
  Clock, 
  FileText, 
  MapPin, 
  Navigation, 
  Shield, 
  ShieldAlert, 
  Trash2, 
  TrendingUp, 
  Upload,
  User as UserIcon,
  Zap,
  LogOut,
  Settings,
  Globe,
  ShieldCheck,
  ExternalLink,
  Mic,
  MicOff
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { geminiService } from './services/geminiService';
import { cn } from './lib/utils';
import { CityStats, MaintenanceTicket, TrafficSignal, MapMarker } from './types';

interface UserProfile {
  uid: string;
  name: string;
  role: 'Citizen' | 'Police Officer' | 'Administrator';
  avatar: string;
  email: string;
}

interface CityLocation {
  name: string;
  lat: number;
  lng: number;
  description: string;
}

const MOCK_USERS: UserProfile[] = [
  { uid: 'user_1', name: 'Arjun Sharma', role: 'Citizen', avatar: 'AS', email: 'arjun@example.com' },
  { uid: 'user_2', name: 'Officer Rajesh', role: 'Police Officer', avatar: 'OR', email: 'rajesh.p@police.gov.in' },
  { uid: 'user_3', name: 'Admin Priya', role: 'Administrator', avatar: 'AP', email: 'admin@urbanpulse.ai' },
  { uid: 'user_4', name: 'Officer Vikram', role: 'Police Officer', avatar: 'OV', email: 'vikram.v@police.gov.in' },
  { uid: 'user_5', name: 'Officer Sneha', role: 'Police Officer', avatar: 'OS', email: 'sneha.s@police.gov.in' },
  { uid: 'user_6', name: 'Rohan Mehra', role: 'Citizen', avatar: 'RM', email: 'rohan@example.com' },
  { uid: 'user_7', name: 'Sita Devi', role: 'Citizen', avatar: 'SD', email: 'sita@example.com' }
];

const CITY_LOCATIONS: CityLocation[] = [
  { name: 'Mumbai - Marine Drive', lat: 18.9440, lng: 72.8230, description: 'Netaji Subhash Chandra Bose Road, iconic promenade with high tourist and local traffic' },
  { name: 'Delhi - Connaught Place', lat: 28.6315, lng: 77.2167, description: 'Rajiv Chowk, central business district with complex traffic patterns and radial roads' },
  { name: 'Bangalore - Indiranagar', lat: 12.9719, lng: 77.6412, description: '100 Feet Road, busy commercial and residential hub with high vehicle density' },
  { name: 'Hyderabad - Banjara Hills', lat: 17.4156, lng: 78.4347, description: 'Road No. 1, upscale neighborhood with hilly terrain and heavy flow' },
  { name: 'Chennai - T. Nagar', lat: 13.0418, lng: 80.2341, description: 'Ranganathan Street, major shopping district with extreme pedestrian density' },
  { name: 'Kolkata - Park Street', lat: 22.5487, lng: 88.3522, description: 'Mother Teresa Sarani, historic entertainment and dining hub' },
  { name: 'Pune - Koregaon Park', lat: 18.5362, lng: 73.8940, description: 'North Main Road, premium residential and commercial area' },
  { name: 'Ahmedabad - SG Highway', lat: 23.0225, lng: 72.5714, description: 'Sarkhej-Gandhinagar Highway, major arterial road with rapid development' }
];

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(MOCK_USERS[0]);
  const [location, setLocation] = useState<CityLocation>(CITY_LOCATIONS[0]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'traffic' | 'accident' | 'violation' | 'pothole' | 'cleanliness' | 'officer' | 'patrol'>('dashboard');
  const [stats, setStats] = useState<CityStats>({
    safetyScore: 84,
    activeAlerts: 2,
    trafficDensity: 'Medium',
    rewardPoints: 120
  });
  const [tickets, setTickets] = useState<MaintenanceTicket[]>([]);
  const [signals, setSignals] = useState<TrafficSignal[]>([]);
  const [markers, setMarkers] = useState<MapMarker[]>([]);
  const [groundingLinks, setGroundingLinks] = useState<any[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [lastAnalyzedType, setLastAnalyzedType] = useState<string | null>(null);
  const [reportDescription, setReportDescription] = useState('');
  const [manualLocation, setManualLocation] = useState('');
  const [useCurrentLocation, setUseCurrentLocation] = useState(false);
  const [currentCoords, setCurrentCoords] = useState<{lat: number, lng: number} | null>(null);
  const [trafficIntel, setTrafficIntel] = useState<string | null>(null);
  const [loadingIntel, setLoadingIntel] = useState(false);
  const [quotaError, setQuotaError] = useState(false);

  // Dynamic Data Generation based on City
  useEffect(() => {
    const updateCityData = async () => {
      setLoadingIntel(true);
      
      // Simulate dynamic stats based on city name
      const seed = location.name.length;
      const newStats: CityStats = {
        safetyScore: 70 + (seed % 25),
        activeAlerts: seed % 5,
        trafficDensity: seed % 3 === 0 ? 'High' : seed % 3 === 1 ? 'Medium' : 'Low',
        rewardPoints: 100 + (seed * 2)
      };
      setStats(newStats);

      // Generate dynamic signals
      const newSignals: TrafficSignal[] = [
        { lane: 'North Junction', vehicleCount: 10 + (seed % 20), greenDuration: 20 + (seed % 30) },
        { lane: 'South Junction', vehicleCount: 5 + (seed % 15), greenDuration: 15 + (seed % 25) },
        { lane: 'East Link', vehicleCount: 15 + (seed % 25), greenDuration: 30 + (seed % 40) },
        { lane: 'West Link', vehicleCount: 8 + (seed % 12), greenDuration: 12 + (seed % 20) }
      ];
      setSignals(newSignals);

      // Generate dynamic markers
      const newMarkers: MapMarker[] = [
        { id: 'm1', type: 'traffic', x: 20 + (seed % 40), y: 30 + (seed % 30), label: 'Congestion' },
        { id: 'm2', type: 'hazard', x: 60 + (seed % 30), y: 50 + (seed % 40), label: 'Pothole' },
        { id: 'm3', type: 'accident', x: 40 + (seed % 20), y: 70 + (seed % 20), label: 'Minor Scrape' }
      ];
      setMarkers(newMarkers);

      // Fetch AI Traffic Intel for the city
      try {
        const intel = await geminiService.getRealTimeTrafficIntel(location.name);
        setTrafficIntel(intel);
        setQuotaError(false);
      } catch (error: any) {
        console.error("Failed to fetch traffic intel:", error);
        handleQuotaError(error);
      } finally {
        setLoadingIntel(false);
      }
    };

    updateCityData();
  }, [location]);

  // Geolocation handling
  useEffect(() => {
    if (useCurrentLocation) {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setCurrentCoords({
              lat: position.coords.latitude,
              lng: position.coords.longitude
            });
          },
          (error) => {
            console.error("Geolocation error:", error);
            setUseCurrentLocation(false);
          }
        );
      } else {
        setUseCurrentLocation(false);
      }
    } else {
      setCurrentCoords(null);
    }
  }, [useCurrentLocation]);

  const handleOfficerAction = async (ticketId: string, action: 'dispatch' | 'validate', rewardAmount?: number) => {
    const newStatus = action === 'validate' ? 'Resolved' : 'In Progress';
    
    // Update local state
    if (action === 'validate') {
      const points = rewardAmount || 50;
      setStats(prev => ({
        ...prev,
        safetyScore: Math.min(100, prev.safetyScore + 2),
        rewardPoints: prev.rewardPoints + points
      }));
    }
    setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status: newStatus, rewardAmount: rewardAmount || t.rewardAmount } : t));
  };
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showLocationMenu, setShowLocationMenu] = useState(false);
  const [citySearch, setCitySearch] = useState('');
  const [loadingTraffic, setLoadingTraffic] = useState(false);
  const [searchingHospitals, setSearchingHospitals] = useState(false);
  const [isAuthReady, setIsAuthReady] = useState(true);
  const [signingIn, setSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [notificationPhone, setNotificationPhone] = useState('');
  const [notificationEmail, setNotificationEmail] = useState('');
  const [enableNotifications, setEnableNotifications] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [activeCommsUnit, setActiveCommsUnit] = useState<any | null>(null);
  const [commsMessage, setCommsMessage] = useState('');
  const [commsLog, setCommsLog] = useState<{unitId: string, message: string, time: string, type: 'sent' | 'received'}[]>([]);
  const [showNotification, setShowNotification] = useState<{message: string, type: 'success' | 'info' | 'warning'} | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getImageSrc = (data: string | undefined) => {
    if (!data) return '';
    if (data.startsWith('data:')) return data;
    return `data:image/jpeg;base64,${data}`;
  };

  const handleFindHospitals = async () => {
    setSearchingHospitals(true);
    try {
      const coords = currentCoords || { lat: location.lat, lng: location.lng };
      const response = await geminiService.findNearbyHospitals(manualLocation || location.name, coords);
      
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        const extractedLinks = chunks
          .filter((c: any) => c.maps?.uri)
          .map((c: any) => ({
            uri: c.maps.uri,
            title: c.maps.title || 'View on Google Maps'
          }));
        setGroundingLinks(prev => {
          const existingUris = new Set(prev.map(l => l.uri));
          const newLinks = extractedLinks.filter(l => !existingUris.has(l.uri));
          return [...prev, ...newLinks];
        });
      }
      
      if (response.text) {
        setAnalysisResult(prev => prev ? `${prev}\n\n### ADDITIONAL HOSPITAL DATA:\n${response.text}` : response.text);
      }
    } catch (error: any) {
      console.error("Failed to find hospitals:", error);
      handleQuotaError(error);
    } finally {
      setSearchingHospitals(false);
    }
  };

  const handleSendMessage = () => {
    if (!commsMessage.trim() || !activeCommsUnit) return;
    
    const newLogEntry = {
      unitId: activeCommsUnit.id,
      message: commsMessage,
      time: new Date().toLocaleTimeString(),
      type: 'sent' as const
    };
    
    setCommsLog(prev => [...prev, newLogEntry]);
    setCommsMessage('');
    
    // Simulate response
    setTimeout(() => {
      const responses = [
        "Copy that, proceeding to location.",
        "Unit received. Maintaining patrol route.",
        "Understood. Any specific instructions?",
        "Acknowledged. Status: Green.",
        "Loud and clear. Over."
      ];
      const response = {
        unitId: activeCommsUnit.id,
        message: responses[Math.floor(Math.random() * responses.length)],
        time: new Date().toLocaleTimeString(),
        type: 'received' as const
      };
      setCommsLog(prev => [...prev, response]);
    }, 1500);
  };

  const handleUpdateSignals = () => {
    setSignals(prev => prev.map(s => ({
      ...s,
      greenDuration: Math.floor(Math.random() * 40) + 15
    })));
    setShowNotification({
      message: `Signal patterns optimized for ${location.name}. Flow efficiency increased by 12%.`,
      type: 'success'
    });
    setTimeout(() => setShowNotification(null), 4000);
  };

  const handleBroadcastAlert = () => {
    setShowNotification({
      message: `Emergency broadcast transmitted to all units in ${location.name}.`,
      type: 'info'
    });
    setTimeout(() => setShowNotification(null), 4000);
  };

  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setShowNotification({
        message: "Speech recognition is not supported in your browser.",
        type: 'warning'
      });
      setTimeout(() => setShowNotification(null), 4000);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsRecording(true);
      setShowNotification({
        message: "Listening... speak now.",
        type: 'info'
      });
      setTimeout(() => setShowNotification(null), 2000);
    };

    recognition.onresult = (event: any) => {
      let transcript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setReportDescription(prev => {
        // Avoid duplicate appending if it's interim
        if (event.results[event.results.length - 1].isFinal) {
          return prev ? `${prev} ${transcript}` : transcript;
        }
        return prev; // For now, only append final results to avoid messy state
      });
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error:", event.error);
      setIsRecording(false);
      setShowNotification({
        message: `Microphone error: ${event.error}`,
        type: 'warning'
      });
      setTimeout(() => setShowNotification(null), 4000);
    };

    recognition.onend = () => {
      setIsRecording(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleGoogleSignIn = async (mockUser: UserProfile) => {
    if (signingIn) return;
    setSigningIn(true);
    setAuthError(null);
    
    try {
      // Mock sign-in for demo
      setTimeout(() => {
        setUser(mockUser);
        if (mockUser.role === 'Police Officer') {
          setActiveTab('officer');
        } else {
          setActiveTab('dashboard');
        }
        setSigningIn(false);
      }, 800);
    } catch (error: any) {
      console.error("Sign-In failed:", error);
      setAuthError(`Sign-in failed: ${error.message}`);
      setSigningIn(false);
    }
  };

  // Real-time simulation for map markers
  useEffect(() => {
    const interval = setInterval(() => {
      setMarkers(prev => {
        // Randomly add or remove a marker
        if (prev.length > 5) {
          return prev.slice(1);
        }
        const types: ('traffic' | 'hazard' | 'accident')[] = ['traffic', 'hazard', 'accident'];
        const newMarker: MapMarker = {
          id: `m-${Math.random().toString(36).substr(2, 9)}`,
          type: types[Math.floor(Math.random() * types.length)],
          x: Math.random() * 80 + 10,
          y: Math.random() * 80 + 10,
          label: 'AI Detected'
        };
        return [...prev, newMarker];
      });
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleQuotaError = (error: any) => {
    console.error("AI Error detected:", error);
    const errorStr = JSON.stringify(error).toUpperCase();
    const errorMsg = (error.message || "").toUpperCase();
    
    if (
      errorStr.includes('RESOURCE_EXHAUSTED') || 
      errorStr.includes('429') || 
      errorMsg.includes('RESOURCE_EXHAUSTED') || 
      errorMsg.includes('429') ||
      error.status === 'RESOURCE_EXHAUSTED' ||
      (error.error && error.error.status === 'RESOURCE_EXHAUSTED')
    ) {
      setQuotaError(true);
      return true;
    }
    return false;
  };

  const fetchTrafficIntel = async (loc: typeof location) => {
    setLoadingTraffic(true);
    try {
      const result = await geminiService.getRealTimeTrafficIntel(loc.name, { lat: loc.lat, lng: loc.lng });
      setTrafficIntel(result);
      setQuotaError(false);
    } catch (error: any) {
      console.error("Failed to fetch traffic intel:", error);
      handleQuotaError(error);
    } finally {
      setLoadingTraffic(false);
    }
  };

  // Fetch traffic intel on location change if in traffic tab
  useEffect(() => {
    if (activeTab === 'traffic') {
      fetchTrafficIntel(location);
    }
  }, [location, activeTab]);

  const handleReportIncident = () => {
    // If not in a reporting tab, switch to accident
    if (activeTab === 'dashboard' || activeTab === 'traffic' || activeTab === 'officer') {
      setActiveTab('accident');
    }
    // Trigger file input
    setTimeout(() => {
      fileInputRef.current?.click();
    }, 100);
  };

  const openApiKeyDialog = async () => {
    try {
      if ((window as any).aistudio && typeof (window as any).aistudio.openSelectKey === 'function') {
        await (window as any).aistudio.openSelectKey();
        setQuotaError(false);
      } else {
        alert("API Key selection is only available when running in AI Studio.");
      }
    } catch (err) {
      console.error("Failed to open API key dialog:", err);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Switch to a reporting tab if we're on dashboard or traffic
    if (activeTab === 'dashboard' || activeTab === 'traffic' || activeTab === 'officer') {
      setActiveTab('accident');
    }

    setAnalyzing(true);
    setAnalysisResult(null);

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const fullBase64 = reader.result as string;
        const base64Data = fullBase64.split(',')[1];
        
        const blockMap: Record<string, string> = {
          'accident': 'Accident',
          'violation': 'Traffic Violation',
          'pothole': 'Pothole',
          'cleanliness': 'Cleanliness',
          'traffic': 'Traffic',
          'dashboard': 'Accident'
        };
        const block = blockMap[activeTab] || 'Accident';
        
        const reportLocationName = manualLocation || location.name;
        
        const prompt = `URGENT ACTION REQUIRED: Analyze this ${block} at ${reportLocationName}.
        
        You MUST provide a comprehensive text response with these EXACT sections:
        
        1. COMPLETE INCIDENT DESCRIPTION:
        (Describe the scene in detail: vehicles, damage, injuries, and surroundings)
        
        2. VEHICLE METADATA:
        Number Plate: [Detected License String or 'Not detected']
        Brand: [Brand Name or 'Unknown']
        Model: [Model Name or 'Unknown']
        Color: [Vehicle Color or 'Unknown']
        
        ${block === 'Accident' ? `3. NEAREST HOSPITALS:
        (You MUST use the Google Maps tool to find at least 3 hospitals near ${reportLocationName}. List their full names and estimated distances in this text response. This is a life-saving requirement.)` : ''}
        
        User's Description: ${reportDescription || `User reported ${activeTab} issue.`}
        
        IMPORTANT: Do not just use tools. You MUST write out the full report in your response text${block === 'Accident' ? ', especially the hospital names' : ''}.`;

        try {
          const response = await geminiService.analyzeUrbanData(
            { mimeType: file.type, data: base64Data },
            prompt,
            useCurrentLocation && currentCoords ? currentCoords : { lat: location.lat, lng: location.lng }
          );
          
          // Improved text extraction
          let result = "";
          if (response.text) {
            result = response.text;
          } else if (response.candidates?.[0]?.content?.parts) {
            result = response.candidates[0].content.parts
              .map(p => p.text || "")
              .filter(t => t.length > 0)
              .join('\n');
          }
          
          // Handle case where model only returns function calls
          const functionCalls = response.functionCalls;
          if (!result && functionCalls && functionCalls.length > 0) {
            const call = functionCalls.find(c => c.name === 'send_emergency_email');
            if (call) {
              const { location: locName, description, severity, numberPlate } = call.args as any;
              result = `### EMERGENCY REPORT GENERATED\n\n**Location:** ${locName}\n**Severity:** ${severity}\n**Description:** ${description}\n**Detected Plate:** ${numberPlate || 'Not detected'}\n\n*Emergency services have been notified.*`;
            }
          }
          
          // If still no text, check grounding metadata to build a fallback
          if (!result && response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
            const chunks = response.candidates[0].groundingMetadata.groundingChunks;
            const hospitalNames = chunks
              .filter((c: any) => c.maps?.title)
              .map((c: any) => c.maps.title)
              .join(', ');
            
            if (hospitalNames) {
              result = `### LOCAL INTELLIGENCE ANALYSIS\n\nIncident reported at **${reportLocationName}**. \n\n**Nearby Hospitals Identified:** ${hospitalNames}.\n\n*Please check the evidence image for visual verification.*`;
            }
          }
          
          if (!result) {
            result = "No detailed analysis available. Please check the evidence image.";
          }
          
          // Extract Grounding Links
          const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
          let extractedLinks: any[] = [];
          if (chunks) {
            extractedLinks = chunks
              .filter((c: any) => c.maps?.uri)
              .map((c: any) => ({
                uri: c.maps.uri,
                title: c.maps.title || 'View on Google Maps'
              }));
            setGroundingLinks(extractedLinks);
          } else {
            setGroundingLinks([]);
          }
          
          // Append hospital names to result if not already there
          if (extractedLinks.length > 0 && !result.toLowerCase().includes('hospital')) {
            const hospitalList = extractedLinks.map(l => l.title).join(', ');
            result += `\n\n### NEAREST HOSPITALS (Identified via AI):\n${hospitalList}`;
          }
          
          setAnalysisResult(result);
          setLastAnalyzedType(block);
          
          // Extract Number Plate from result text
          const plateMatch = result.match(/Number Plate:\s*\[?([^\]\n\r]+)\]?/i) || result.match(/Detected Plate:\s*\[?([^\]\n\r]+)\]?/i);
          const detectedPlate = plateMatch ? plateMatch[1].trim().replace(/[\[\]]/g, '') : 'Not detected';
          
          // Extract Vehicle Details
          const brandMatch = result.match(/Brand:\s*\[?([^\]\n\r]+)\]?/i);
          const modelMatch = result.match(/Model:\s*\[?([^\]\n\r]+)\]?/i);
          const colorMatch = result.match(/Color:\s*\[?([^\]\n\r]+)\]?/i);
          
          const vehicleDetails = {
            brand: brandMatch ? brandMatch[1].trim().replace(/[\[\]]/g, '') : undefined,
            model: modelMatch ? modelMatch[1].trim().replace(/[\[\]]/g, '') : undefined,
            color: colorMatch ? colorMatch[1].trim().replace(/[\[\]]/g, '') : undefined
          };
          
          // Handle Function Calls (already extracted above, but keep the logic for side effects)
          if (functionCalls) {
            for (const call of functionCalls) {
              if (call.name === 'send_emergency_email') {
                const { location: emergencyLocation, description, severity, numberPlate } = call.args as any;
                try {
                  const emailResponse = await fetch('/api/send-emergency-email', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                      location: emergencyLocation, 
                      description, 
                      severity, 
                      numberPlate: numberPlate || detectedPlate,
                      reporterName: user?.name || 'Anonymous'
                    })
                  });
                  
                  if (!emailResponse.ok) {
                    const errorData = await emailResponse.json().catch(() => ({ error: 'Unknown server error' }));
                    console.error("Server failed to send emergency email:", errorData.error);
                    setShowNotification({
                      message: `Failed to send emergency email: ${errorData.error}`,
                      type: 'warning'
                    });
                    setTimeout(() => setShowNotification(null), 6000);
                  } else {
                    console.log("Emergency email sent successfully for:", emergencyLocation);
                    setShowNotification({
                      message: `Emergency alert sent successfully to authorities for ${emergencyLocation}.`,
                      type: 'success'
                    });
                    setTimeout(() => setShowNotification(null), 5000);
                  }
                } catch (emailError) {
                  console.error("Network error sending emergency email:", emailError);
                  setShowNotification({
                    message: "Network error while sending emergency email.",
                    type: 'warning'
                  });
                  setTimeout(() => setShowNotification(null), 5000);
                }
              }
            }
          }
          
        // Save locally
        try {
          const reportLocation = useCurrentLocation && currentCoords 
            ? { lat: currentCoords.lat, lng: currentCoords.lng, name: manualLocation || `Current Location (${currentCoords.lat.toFixed(4)}, ${currentCoords.lng.toFixed(4)})` }
            : { lat: location.lat, lng: location.lng, name: manualLocation || location.name };

          const newTicket: MaintenanceTicket = {
            category: block,
            location: reportLocation,
            lat: reportLocation.lat,
            lng: reportLocation.lng,
            description: reportDescription || result,
            visualData: fullBase64,
            analysisResult: result,
            numberPlate: detectedPlate,
            groundingLinks: extractedLinks,
            status: 'Pending',
            reporterUid: user?.uid || 'anonymous',
            reporterName: user?.name || 'Anonymous',
            createdAt: new Date().toISOString(),
            timestamp: new Date().toISOString(),
            type: block,
            id: `T-${Date.now()}`
          };

          setTickets(prev => [newTicket as any, ...prev]);
          setReportDescription('');

            // Send Notifications if enabled and category matches
            if (enableNotifications && (block === 'Accident' || block === 'Traffic Violation')) {
              const alertMessage = `URGENT: ${block} detected at ${location.name} at ${new Date().toLocaleTimeString()}. Plate: ${detectedPlate}. Reporter: ${user?.name || 'Anonymous'}.`;
              
              // SMS
              if (notificationPhone) {
                try {
                  const smsRes = await fetch('/api/notify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      phoneNumber: notificationPhone,
                      message: alertMessage
                    })
                  });
                  const smsData = await smsRes.json();
                  if (!smsRes.ok) {
                    setShowNotification({
                      message: `SMS notification failed: ${smsData.error}`,
                      type: 'warning'
                    });
                  } else {
                    setShowNotification({
                      message: "SMS notification sent successfully.",
                      type: 'success'
                    });
                  }
                  setTimeout(() => setShowNotification(null), 5000);
                } catch (notifyError) {
                  console.error("Failed to send SMS notification:", notifyError);
                }
              }

              // Email
              if (notificationEmail) {
                try {
                  const emailRes = await fetch('/api/send-emergency-email', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      location: location.name,
                      description: alertMessage,
                      severity: 'High',
                      recipient: notificationEmail, // Send to user's email
                      numberPlate: detectedPlate,
                      reporterName: user?.name || 'Anonymous'
                    })
                  });
                  const emailData = await emailRes.json();
                  if (!emailRes.ok) {
                    setShowNotification({
                      message: `Email notification failed: ${emailData.error}`,
                      type: 'warning'
                    });
                  } else {
                    setShowNotification({
                      message: "Email notification sent successfully.",
                      type: 'success'
                    });
                  }
                  setTimeout(() => setShowNotification(null), 5000);
                } catch (notifyError) {
                  console.error("Failed to send Email notification:", notifyError);
                }
              }
            }
          } catch (error) {
            console.error("Failed to save report locally:", error);
          }
          
          /* 
          if (result.toLowerCase().includes('violation') || result.toLowerCase().includes('pothole') || result.toLowerCase().includes('litter')) {
            setStats(prev => ({ ...prev, rewardPoints: prev.rewardPoints + 20 }));
          }
          */
        } catch (error: any) {
          console.error("Analysis failed:", error);
          handleQuotaError(error);
        } finally {
          setAnalyzing(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (error: any) {
      console.error("Analysis failed:", error);
      handleQuotaError(error);
      setAnalyzing(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl"
        >
          <div className="flex items-center gap-3 mb-8 justify-center">
            <div className="w-12 h-12 bg-cyan-500 rounded-2xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Zap className="text-slate-950 fill-slate-950" size={28} />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">UrbanPulse <span className="text-cyan-400">AI</span></h1>
          </div>
          
          <h2 className="text-xl font-bold text-center mb-2">Welcome Back</h2>
          <p className="text-slate-400 text-center text-sm mb-8">Select a profile to enter the city intelligence system</p>
          
          <AnimatePresence>
            {authError && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-3"
              >
                <AlertTriangle className="text-red-400 shrink-0" size={18} />
                <p className="text-xs text-red-200 leading-relaxed">{authError}</p>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-3">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest text-center mb-2">Select Role & Sign In</p>
            {MOCK_USERS.map((u) => (
              <button 
                key={u.email}
                onClick={() => handleGoogleSignIn(u)}
                disabled={signingIn}
                className={cn(
                  "w-full flex items-center gap-4 p-4 bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 rounded-2xl transition-all group",
                  signingIn ? "opacity-50 cursor-not-allowed" : ""
                )}
              >
                <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold group-hover:bg-cyan-500 group-hover:text-slate-950 transition-colors">
                  {signingIn ? <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"></div> : u.avatar}
                </div>
                <div className="text-left">
                  <p className="font-bold text-slate-100">{u.name}</p>
                  <p className="text-xs text-slate-500">{u.role}</p>
                </div>
                <div className="ml-auto flex items-center gap-2">
                  <Globe size={14} className="text-slate-600 group-hover:text-cyan-400" />
                  <ChevronRight size={18} className="text-slate-600 group-hover:text-cyan-400 transition-colors" />
                </div>
              </button>
            ))}
          </div>
          <p className="mt-6 text-[10px] text-slate-500 text-center">
            Signing in will connect your Google account to the selected role for secure urban data reporting.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-cyan-500/30">
      {/* Global Quota Error Banner */}
      <AnimatePresence>
        {quotaError && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-amber-500 text-slate-950 px-6 py-2 flex items-center justify-between gap-4 overflow-hidden z-[100] relative"
          >
            <div className="flex items-center gap-2 text-xs font-bold">
              <AlertTriangle size={14} />
              <span>AI Quota Exceeded. Please select your own API key to continue using AI features.</span>
            </div>
            <button 
              onClick={openApiKeyDialog}
              className="px-3 py-1 bg-slate-950 text-amber-500 rounded-full text-[10px] font-black uppercase tracking-tighter hover:bg-slate-900 transition-colors shrink-0"
            >
              Select Key
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-slate-900/50 border-r border-slate-800 p-6 flex flex-col gap-8 z-50">
        <div className="flex items-center gap-3 px-2">
          <div className="w-10 h-10 bg-cyan-500 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <Zap className="text-slate-950 fill-slate-950" size={24} />
          </div>
          <h1 className="text-xl font-bold tracking-tight">UrbanPulse <span className="text-cyan-400">AI</span></h1>
        </div>

        <nav className="flex flex-col gap-2">
          <NavItem 
            icon={<Activity size={20} />} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <NavItem 
            icon={<Navigation size={20} />} 
            label="Traffic Intel" 
            active={activeTab === 'traffic'} 
            onClick={() => setActiveTab('traffic')} 
          />
          
          {user?.role === 'Citizen' && (
            <>
              <div className="h-px bg-slate-800 my-2 mx-2" />
              <p className="px-4 text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Reporting</p>
              <NavItem 
                icon={<AlertTriangle size={20} />} 
                label="Accident" 
                active={activeTab === 'accident'} 
                onClick={() => setActiveTab('accident')} 
              />
              <NavItem 
                icon={<Shield size={20} />} 
                label="Traffic Violation" 
                active={activeTab === 'violation'} 
                onClick={() => setActiveTab('violation')} 
              />
              <NavItem 
                icon={<AlertTriangle size={20} />} 
                label="Pothole" 
                active={activeTab === 'pothole'} 
                onClick={() => setActiveTab('pothole')} 
              />
              <NavItem 
                icon={<Trash2 size={20} />} 
                label="Cleanliness" 
                active={activeTab === 'cleanliness'} 
                onClick={() => setActiveTab('cleanliness')} 
              />
            </>
          )}

          {(user?.role === 'Police Officer' || user?.role === 'Administrator') && (
            <>
              <div className="h-px bg-slate-800 my-2 mx-2" />
              <p className="px-4 text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Police Operations</p>
              <NavItem 
                icon={<ShieldAlert size={20} />} 
                label="Officer Feed" 
                active={activeTab === 'officer'} 
                onClick={() => setActiveTab('officer')} 
              />
              <NavItem 
                icon={<Car size={20} />} 
                label="Patrol Management" 
                active={activeTab === 'patrol'} 
                onClick={() => setActiveTab('patrol')} 
              />
            </>
          )}

          {user?.role === 'Administrator' && (
            <>
              <div className="h-px bg-slate-800 my-2 mx-2" />
              <p className="px-4 text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Admin Mode</p>
              <NavItem 
                icon={<Settings size={20} />} 
                label="System Settings" 
                active={activeTab === 'dashboard'} 
                onClick={() => setActiveTab('dashboard')} 
              />
              <NavItem 
                icon={<Globe size={20} />} 
                label="Infrastructure" 
                active={activeTab === 'dashboard'} 
                onClick={() => setActiveTab('dashboard')} 
              />
            </>
          )}
        </nav>

        <div className="mt-auto space-y-4">
          {/* User Profile Card */}
          <div className="relative">
            <button 
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="w-full p-4 bg-slate-800/50 rounded-2xl border border-slate-700/50 flex items-center gap-3 hover:bg-slate-800 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-cyan-500 flex items-center justify-center text-slate-950 font-bold">
                {user.avatar}
              </div>
              <div className="text-left overflow-hidden">
                <p className="text-sm font-bold truncate">{user.name}</p>
                <p className="text-[10px] text-slate-500 uppercase tracking-wider">{user.role}</p>
              </div>
              <Settings size={14} className="ml-auto text-slate-500" />
            </button>

            <AnimatePresence>
              {showUserMenu && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute bottom-full left-0 w-full mb-2 bg-slate-900 border border-slate-800 rounded-2xl p-2 shadow-2xl z-50"
                >
                  <p className="px-3 py-2 text-[10px] text-slate-500 font-bold uppercase tracking-widest">Switch Profile</p>
                  {MOCK_USERS.map(u => (
                    <button 
                      key={u.email}
                      onClick={() => { setUser(u); setShowUserMenu(false); }}
                      className={cn(
                        "w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm transition-colors",
                        user.email === u.email ? "bg-cyan-500/10 text-cyan-400" : "hover:bg-slate-800 text-slate-400"
                      )}
                    >
                      <div className="w-6 h-6 rounded-full bg-slate-700 flex items-center justify-center text-[10px]">
                        {u.avatar}
                      </div>
                      <span>{u.name}</span>
                    </button>
                  ))}
                  <div className="h-px bg-slate-800 my-2" />
                  <button 
                    onClick={() => { 
                      setUser(null); 
                      setShowUserMenu(false); 
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-red-400 hover:bg-red-500/10 transition-colors"
                  >
                    <LogOut size={14} />
                    <span>Logout</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Reward Progress */}
          <div className="p-4 bg-slate-800/30 rounded-2xl border border-slate-700/30">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-slate-400">Citizen Rewards</p>
              <p className="text-xs font-bold text-cyan-400">{stats.rewardPoints} pts</p>
            </div>
            <div className="h-1.5 w-full bg-slate-700 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-cyan-500" 
                initial={{ width: 0 }}
                animate={{ width: `${(stats.rewardPoints % 200) / 2}%` }}
              />
            </div>
          </div>

          {/* Notification Settings */}
          <div className="p-4 bg-slate-800/30 rounded-2xl border border-slate-700/30 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">SMS Alerts</p>
              <button 
                onClick={() => setEnableNotifications(!enableNotifications)}
                className={cn(
                  "w-8 h-4 rounded-full transition-colors relative",
                  enableNotifications ? "bg-cyan-500" : "bg-slate-700"
                )}
              >
                <div className={cn(
                  "absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all",
                  enableNotifications ? "right-0.5" : "left-0.5"
                )} />
              </button>
            </div>
            {enableNotifications && (
              <div className="space-y-2">
                <input 
                  type="tel"
                  value={notificationPhone}
                  onChange={(e) => setNotificationPhone(e.target.value)}
                  placeholder="Phone: +1234567890"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-[10px] focus:outline-none focus:border-cyan-500 transition-colors"
                />
                <input 
                  type="email"
                  value={notificationEmail}
                  onChange={(e) => setNotificationEmail(e.target.value)}
                  placeholder="Email: user@example.com"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-[10px] focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-64 p-8 max-w-7xl mx-auto">
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileUpload} 
          className="hidden" 
          accept="image/*"
        />
        <header className="flex justify-between items-start mb-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="relative">
                <button 
                  onClick={() => setShowLocationMenu(!showLocationMenu)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-full text-xs font-medium text-cyan-400 hover:bg-slate-800 transition-colors"
                >
                  <MapPin size={14} />
                  <span>{location.name}</span>
                  <ChevronRight size={12} className={cn("transition-transform", showLocationMenu ? "rotate-90" : "")} />
                </button>
                
                <AnimatePresence>
                  {showLocationMenu && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute top-full left-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-2xl p-2 shadow-2xl z-50 text-slate-100"
                    >
                      <p className="px-3 py-2 text-[10px] text-slate-500 font-bold uppercase tracking-widest text-left">Select District</p>
                      {CITY_LOCATIONS.map(loc => (
                        <button 
                          key={loc.name}
                          onClick={() => { setLocation(loc); setShowLocationMenu(false); }}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-xl transition-colors group",
                            location.name === loc.name ? "bg-cyan-500/10 text-cyan-400" : "hover:bg-slate-800 text-slate-400"
                          )}
                        >
                          <p className="text-sm font-bold">{loc.name}</p>
                          <p className="text-[10px] opacity-60 group-hover:opacity-100">{loc.description}</p>
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              <span className="text-slate-600">/</span>
              <span className="text-xs text-slate-500 font-mono">{location?.lat?.toFixed(4)}, {location?.lng?.toFixed(4)}</span>
            </div>
            <h2 className="text-3xl font-bold mb-1">
              {activeTab === 'dashboard' && "City Overview"}
              {activeTab === 'traffic' && "Traffic Intelligence"}
              {activeTab === 'accident' && "Accident Reporting"}
              {activeTab === 'violation' && "Traffic Violation"}
              {activeTab === 'pothole' && "Pothole Reporting"}
              {activeTab === 'cleanliness' && "Cleanliness Reporting"}
              {activeTab === 'officer' && "Officer Intelligence Feed"}
            </h2>
            <p className="text-slate-400">Real-time urban intelligence for {location.name}</p>
          </div>
          
          <div className="flex gap-4">
            <div className="flex flex-col items-end">
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">System Status</p>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                <span className="text-xs font-bold">Operational</span>
              </div>
            </div>
            <button 
              onClick={handleReportIncident}
              disabled={analyzing}
              className="flex items-center gap-2 px-4 py-2.5 bg-cyan-500 text-slate-950 font-bold rounded-xl hover:bg-cyan-400 transition-colors shadow-lg shadow-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {analyzing ? (
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Upload size={18} />
              )}
              <span>{analyzing ? 'Processing...' : 'Report Incident'}</span>
            </button>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-10"
            >
              {/* Dashboard City Search */}
              <div className="flex flex-col md:flex-row gap-4 items-end bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
                <div className="flex-1 w-full">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">Analyze Another City</label>
                  <div className="relative">
                    <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-cyan-400" size={18} />
                    <input 
                      type="text"
                      value={citySearch}
                      onChange={(e) => setCitySearch(e.target.value)}
                      placeholder="e.g., Bengaluru, Mysuru, Hubballi..."
                      className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-3 pl-12 pr-4 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                  </div>
                </div>
                <button 
                  onClick={() => {
                    if (citySearch.trim()) {
                      const newLoc = {
                        name: citySearch,
                        lat: 12.9716, // Mock lat for demo
                        lng: 77.5946, // Mock lng for demo
                        description: `Custom dashboard analysis for ${citySearch}`
                      };
                      setLocation(newLoc);
                    }
                  }}
                  className="w-full md:w-auto px-8 py-3 bg-cyan-500 text-slate-950 font-bold rounded-2xl hover:bg-cyan-400 transition-colors shadow-lg shadow-cyan-500/20"
                >
                  Update Dashboard
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard 
                  title="Safety Score" 
                  value={stats.safetyScore} 
                  unit="/100" 
                  icon={<ShieldCheck className="text-emerald-400" />} 
                  trend={`${stats.safetyScore > 80 ? 'Excellent' : 'Stable'} safety rating`}
                  color="emerald"
                />
              <StatCard 
                title="Active Alerts" 
                value={stats.activeAlerts} 
                unit="Critical" 
                icon={<AlertTriangle className="text-amber-400" />} 
                trend={`${stats.activeAlerts} incidents requiring attention`}
                color="amber"
              />
              <StatCard 
                title="Traffic Flow" 
                value={stats.trafficDensity} 
                unit="Density" 
                icon={<Car className="text-cyan-400" />} 
                trend="Dynamic signals optimized"
                color="cyan"
              />
                <StatCard 
                  title="Citizen Reports" 
                  value={tickets.length} 
                  unit="Active" 
                  icon={<FileText className="text-indigo-400" />} 
                  trend={`${tickets.filter(t => t.status === 'Resolved').length} resolved this week`}
                  color="indigo"
                />
              </div>

              {/* AI Real-time Insights */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold flex items-center gap-2">
                    <Zap className="text-cyan-400" size={20} />
                    AI Real-time Insights: {location.name}
                  </h3>
                  {(loadingIntel || loadingTraffic) && (
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <div className="w-3 h-3 border-2 border-slate-500 border-t-transparent rounded-full animate-spin"></div>
                      Fetching latest intelligence...
                    </div>
                  )}
                </div>
                
                {quotaError && (
                  <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="text-amber-500 shrink-0 mt-0.5" size={18} />
                      <div className="space-y-2">
                        <p className="text-sm text-amber-200 font-medium">AI Quota Exceeded</p>
                        <p className="text-xs text-amber-200/60 leading-relaxed">
                          The free tier quota for the Gemini API has been reached. You can continue by selecting your own API key.
                        </p>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={openApiKeyDialog}
                            className="flex items-center gap-2 px-3 py-1.5 bg-amber-500 text-slate-950 rounded-lg text-[10px] font-bold hover:bg-amber-400 transition-colors"
                          >
                            <Settings size={12} />
                            Select API Key
                          </button>
                          <button 
                            onClick={() => fetchTrafficIntel(location)}
                            className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 text-amber-500 border border-amber-500/20 rounded-lg text-[10px] font-bold hover:bg-slate-700 transition-colors"
                          >
                            <Clock size={12} />
                            Retry
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {trafficIntel ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="prose prose-invert max-w-none text-sm text-slate-300">
                      <ReactMarkdown>{trafficIntel}</ReactMarkdown>
                    </div>
                    <div className="space-y-4">
                      <div className="p-4 bg-cyan-500/5 border border-cyan-500/10 rounded-2xl">
                        <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-widest mb-2">AI Optimization Strategy</h4>
                        <p className="text-xs text-slate-400 leading-relaxed">
                          UrbanPulse AI is currently prioritizing {location.name.split(' - ')[1] || 'main arterial roads'} based on detected congestion patterns. 
                          Dynamic signal timing is being adjusted to reduce wait times at major junctions.
                        </p>
                      </div>
                      <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-700/50">
                        <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Safety Advisory</h4>
                        <p className="text-xs text-slate-400 leading-relaxed">
                          {stats.safetyScore < 75 
                            ? "Caution advised in high-density zones. Increased patrol presence recommended." 
                            : "Standard safety protocols active. No major anomalies detected in pedestrian zones."}
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="py-12 text-center text-slate-500 italic text-sm">
                    {loadingIntel ? "Analyzing urban data streams..." : "No real-time intelligence available for this location yet."}
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === 'traffic' && (
            <motion.div 
              key="traffic"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* City Search for Traffic Intel */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 flex flex-col md:flex-row items-center gap-4">
                <div className="flex-1 w-full">
                  <label className="block text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-2 ml-1">Enter City for Traffic Intelligence</label>
                  <div className="relative">
                    <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-cyan-400" size={18} />
                    <input 
                      type="text"
                      value={citySearch}
                      onChange={(e) => setCitySearch(e.target.value)}
                      placeholder="e.g., Bengaluru, Mysuru, Hubballi..."
                      className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-3 pl-12 pr-4 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                  </div>
                </div>
                <button 
                  onClick={() => {
                    if (citySearch.trim()) {
                      const newLoc = {
                        name: citySearch,
                        lat: 12.9716, // Mock lat for demo
                        lng: 77.5946, // Mock lng for demo
                        description: `Custom traffic analysis for ${citySearch}`
                      };
                      setLocation(newLoc);
                    }
                  }}
                  disabled={loadingTraffic}
                  className="w-full md:w-auto px-8 py-3 bg-cyan-500 text-slate-950 font-bold rounded-2xl hover:bg-cyan-400 transition-colors shadow-lg shadow-cyan-500/20 disabled:opacity-50"
                >
                  {loadingTraffic ? "Analyzing..." : "Analyze Traffic"}
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8">
                  {trafficIntel && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-slate-900/50 border border-cyan-500/20 rounded-3xl p-6"
                    >
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold flex items-center gap-2">
                          <Activity size={20} className="text-cyan-400" />
                          Real-Time Traffic Intelligence: {location.name}
                        </h3>
                        <div className="flex items-center gap-2 px-3 py-1 bg-cyan-500/10 text-cyan-400 text-[10px] font-bold rounded-full animate-pulse border border-cyan-500/20">
                          <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full"></div>
                          LIVE DATA
                        </div>
                      </div>
                      <div className="prose prose-invert prose-sm max-w-none text-slate-300">
                        <ReactMarkdown>{trafficIntel}</ReactMarkdown>
                      </div>
                    </motion.div>
                  )}
                  
                  <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 relative overflow-hidden">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold flex items-center gap-2">
                      <Camera size={20} className="text-cyan-400" />
                      Live Feed: {location.name} Intersection
                    </h3>
                    <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 text-red-400 text-xs font-bold rounded-full animate-pulse">
                      <div className="w-1.5 h-1.5 bg-red-500 rounded-full"></div>
                      LIVE
                    </div>
                  </div>
                  <div className="aspect-video bg-slate-800 rounded-2xl relative group overflow-hidden">
                    <img 
                      src={`https://images.unsplash.com/photo-1545147422-699396744972?auto=format&fit=crop&q=80&w=1200&sig=${location.name}`} 
                      alt="Traffic Camera" 
                      className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="grid grid-cols-2 gap-4 p-4 w-full h-full">
                        {signals.map((s, i) => (
                          <div key={i} className="border border-cyan-500/30 bg-slate-950/40 backdrop-blur-sm rounded-xl p-4 flex flex-col justify-center">
                            <p className="text-xs text-slate-400 mb-1">{s.lane}</p>
                            <div className="flex justify-between items-end">
                              <span className="text-2xl font-bold text-cyan-400">{s.vehicleCount}</span>
                              <span className="text-xs text-slate-500">Vehicles</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
                  <h3 className="text-xl font-bold mb-6">Dynamic Signal Timing</h3>
                  <div className="space-y-4">
                    {signals.map((s, i) => (
                      <div key={i} className="flex items-center gap-4">
                        <div className="w-32 text-sm text-slate-400 truncate">{s.lane}</div>
                        <div className="flex-1 h-3 bg-slate-800 rounded-full overflow-hidden">
                          <motion.div 
                            className="h-full bg-cyan-500"
                            initial={{ width: 0 }}
                            animate={{ width: `${(s.greenDuration / 60) * 100}%` }}
                          />
                        </div>
                        <div className="w-16 text-right font-mono text-cyan-400">{s.greenDuration}s</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
                  <h3 className="text-lg font-bold mb-4">Traffic Insights</h3>
                  <div className="space-y-4">
                    <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-700/50">
                      <p className="text-sm text-slate-300 leading-relaxed">
                        AI Orchestrator has optimized signal cycles at {location.name}, reducing average wait time by <span className="text-cyan-400 font-bold">18%</span>.
                      </p>
                    </div>
                    <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-700/50">
                      <p className="text-sm text-slate-300 leading-relaxed">
                        Current density in {location.name} is {stats.trafficDensity}. Dynamic rerouting active.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
          )}

          {(activeTab === 'accident' || activeTab === 'violation' || activeTab === 'pothole' || activeTab === 'cleanliness') && (
            <motion.div 
              key="reporting"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-8"
            >
              <div className="space-y-8">
                <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8 text-center">
                  <div className="w-20 h-20 bg-cyan-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Upload className="text-cyan-400" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold mb-2">
                    {activeTab === 'accident' && "Report Accident"}
                    {activeTab === 'violation' && "Report Traffic Violation"}
                    {activeTab === 'pothole' && "Report Pothole"}
                    {activeTab === 'cleanliness' && "Report Cleanliness Issue"}
                  </h3>
                  <p className="text-slate-400 mb-8 max-w-sm mx-auto">
                    Reporting from <span className="text-cyan-400 font-bold">{location.name}</span>. Our AI will automatically process your report.
                  </p>

                  <div className="mb-6 text-left space-y-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 ml-1">Location Options</label>
                      <div className="flex flex-col gap-3">
                        <button 
                          onClick={() => setUseCurrentLocation(!useCurrentLocation)}
                          className={cn(
                            "flex items-center gap-2 px-4 py-2 rounded-xl border transition-all text-xs font-bold",
                            useCurrentLocation 
                              ? "bg-cyan-500/20 border-cyan-500 text-cyan-400" 
                              : "bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600"
                          )}
                        >
                          <MapPin size={14} />
                          {useCurrentLocation ? "Using Current Location" : "Use Current Location"}
                        </button>
                        
                        <div className="relative">
                          <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                          <input 
                            type="text"
                            value={manualLocation}
                            onChange={(e) => setManualLocation(e.target.value)}
                            placeholder="Enter specific location or landmark..."
                            className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-3 pl-12 pr-4 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2 ml-1">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">Description (Optional)</label>
                        <button 
                          onClick={toggleRecording}
                          className={cn(
                            "flex items-center gap-1.5 px-2 py-1 rounded-lg transition-all text-[10px] font-bold",
                            isRecording 
                              ? "bg-red-500/20 text-red-400 animate-pulse" 
                              : "bg-slate-800 text-slate-400 hover:text-cyan-400"
                          )}
                        >
                          {isRecording ? <MicOff size={12} /> : <Mic size={12} />}
                          {isRecording ? "Stop Recording" : "Voice Input"}
                        </button>
                      </div>
                      <textarea 
                        value={reportDescription}
                        onChange={(e) => setReportDescription(e.target.value)}
                        placeholder={
                          activeTab === 'accident' ? "Describe the accident (e.g., 'Two-car collision at intersection')..." :
                          activeTab === 'violation' ? "Describe the violation (e.g., 'Rider without helmet', 'Signal jump')..." :
                          activeTab === 'pothole' ? "Describe the pothole location and size..." :
                          "Describe the cleanliness issue (e.g., 'Litter accumulation', 'Overflowing bin')..."
                        }
                        className="w-full bg-slate-800 border border-slate-700 rounded-2xl p-4 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors min-h-[100px] resize-none"
                      />
                    </div>
                  </div>
                  
                  <div className="flex flex-col gap-3">
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      disabled={analyzing}
                      className={cn(
                        "w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-3",
                        analyzing ? "bg-slate-800 text-slate-500 cursor-not-allowed" : "bg-cyan-500 text-slate-950 hover:bg-cyan-400 shadow-lg shadow-cyan-500/20"
                      )}
                    >
                      {analyzing ? (
                        <>
                          <div className="w-5 h-5 border-2 border-slate-500 border-t-transparent rounded-full animate-spin"></div>
                          <span>AI Processing...</span>
                        </>
                      ) : (
                        <>
                          <Camera size={20} />
                          <span>Select Image to Analyze</span>
                        </>
                      )}
                    </button>

                    {activeTab === 'accident' && (
                      <button 
                        onClick={handleFindHospitals}
                        disabled={searchingHospitals}
                        className={cn(
                          "w-full py-3 rounded-2xl font-bold transition-all flex items-center justify-center gap-3 border",
                          searchingHospitals 
                            ? "bg-slate-800 border-slate-700 text-slate-500 cursor-not-allowed" 
                            : "bg-red-500/10 border-red-500/20 text-red-400 hover:bg-red-500/20 hover:border-red-500/40 shadow-lg shadow-red-500/5"
                        )}
                      >
                        {searchingHospitals ? (
                          <>
                            <div className="w-4 h-4 border-2 border-red-500/50 border-t-transparent rounded-full animate-spin"></div>
                            <span>Locating Hospitals...</span>
                          </>
                        ) : (
                          <>
                            <MapPin size={18} />
                            <span>Find Nearby Hospitals</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
                  <h3 className="text-lg font-bold mb-4">Recent Reports in {location.name}</h3>
                  <div className="space-y-3">
                    {tickets.filter(t => 
                      (activeTab === 'accident' && t.category === 'Accident') ||
                      (activeTab === 'violation' && t.category === 'Traffic Violation') ||
                      (activeTab === 'pothole' && t.category === 'Pothole') ||
                      (activeTab === 'cleanliness' && t.category === 'Cleanliness')
                    ).map((t) => (
                      <div key={t.id} className="flex items-center justify-between p-4 bg-slate-800/30 rounded-2xl border border-slate-700/30">
                        <div className="flex items-center gap-4">
                          <div className={cn(
                            "w-10 h-10 rounded-xl flex items-center justify-center",
                            t.category === 'Accident' ? "bg-red-500/10 text-red-400" :
                            t.category === 'Traffic Violation' ? "bg-amber-500/10 text-amber-400" :
                            t.category === 'Pothole' ? "bg-orange-500/10 text-orange-400" :
                            "bg-emerald-500/10 text-emerald-400"
                          )}>
                            {t.category === 'Accident' ? <AlertTriangle size={20} /> : 
                             t.category === 'Traffic Violation' ? <Shield size={20} /> :
                             t.category === 'Pothole' ? <AlertTriangle size={20} /> :
                             <Trash2 size={20} />}
                          </div>
                          <div>
                            <p className="font-bold">{t.type || t.category} Detected</p>
                            <p className="text-xs text-slate-500 flex items-center gap-1">
                              <MapPin size={10} /> {t.location?.lat?.toFixed(4)}, {t.location?.lng?.toFixed(4)}
                            </p>
                          </div>
                        </div>
                        <div className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                          t.status === 'In Progress' ? "bg-cyan-500/10 text-cyan-400" : "bg-slate-700 text-slate-400"
                        )}>
                          {t.status}
                        </div>
                      </div>
                    ))}
                    {tickets.filter(t => 
                      (activeTab === 'accident' && t.category === 'Accident') ||
                      (activeTab === 'violation' && t.category === 'Traffic Violation') ||
                      (activeTab === 'pothole' && t.category === 'Pothole') ||
                      (activeTab === 'cleanliness' && t.category === 'Cleanliness')
                    ).length === 0 && (
                      <div className="py-8 text-center text-slate-500 text-sm italic">
                        No recent reports for this category.
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8 overflow-y-auto max-h-[600px]">
                <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                  <Activity size={20} className="text-cyan-400" />
                  AI Agent Output
                </h3>
                
                {quotaError && (
                  <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="text-amber-500 shrink-0 mt-0.5" size={18} />
                      <div className="space-y-2">
                        <p className="text-sm text-amber-200 font-medium">AI Quota Exceeded</p>
                        <p className="text-xs text-amber-200/60 leading-relaxed">
                          The free tier quota for the Gemini API has been reached. You can continue by selecting your own API key.
                        </p>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={openApiKeyDialog}
                            className="flex items-center gap-2 px-3 py-1.5 bg-amber-500 text-slate-950 rounded-lg text-[10px] font-bold hover:bg-amber-400 transition-colors"
                          >
                            <Settings size={12} />
                            Select API Key
                          </button>
                          <button 
                            onClick={() => setQuotaError(false)}
                            className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 text-amber-500 border border-amber-500/20 rounded-lg text-[10px] font-bold hover:bg-slate-700 transition-colors"
                          >
                            <Clock size={12} />
                            Clear Error
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {analysisResult ? (
                  <div className="space-y-6">
                    <div className="prose prose-invert max-w-none">
                      <ReactMarkdown>{analysisResult}</ReactMarkdown>
                    </div>
                    
                    {/* Agent A: Hospital Mapping Highlight */}
                    {lastAnalyzedType === 'Accident' && (
                      <div className="p-6 bg-red-500/10 border border-red-500/20 rounded-3xl shadow-lg shadow-red-500/5">
                        <div className="flex items-center gap-3 text-red-400 mb-4">
                          <div className="w-10 h-10 bg-red-500/20 rounded-xl flex items-center justify-center">
                            <Activity size={24} />
                          </div>
                          <div>
                            <h4 className="text-sm font-bold uppercase tracking-widest">Agent A: Emergency Logistics</h4>
                            <p className="text-[10px] text-red-400/60 font-bold">CRITICAL INCIDENT RESPONSE ACTIVE</p>
                          </div>
                        </div>
                        <p className="text-sm text-slate-200 mb-6 font-medium leading-relaxed">
                          Help is on the way. Our AI has alerted the nearest emergency services and identified medical facilities based on your precise location.
                        </p>
                        <div className="grid grid-cols-1 gap-3">
                          {groundingLinks.length > 0 ? (
                            groundingLinks.map((link, idx) => {
                              const isMedical = link.title.toLowerCase().includes('hospital') || 
                                              link.title.toLowerCase().includes('medical') || 
                                              link.title.toLowerCase().includes('clinic') ||
                                              link.title.toLowerCase().includes('health');
                              
                              return (
                                <a 
                                  key={idx}
                                  href={link.uri}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className={cn(
                                    "flex items-center gap-4 p-4 rounded-2xl border transition-all group",
                                    isMedical 
                                      ? "bg-slate-900/80 hover:bg-slate-900 border-red-500/20 hover:border-red-500/40" 
                                      : "bg-slate-900/40 hover:bg-slate-900/60 border-slate-800 hover:border-slate-700"
                                  )}
                                >
                                  <div className={cn(
                                    "w-10 h-10 rounded-xl flex items-center justify-center transition-colors",
                                    isMedical ? "bg-red-500/10 group-hover:bg-red-500/20" : "bg-slate-800 group-hover:bg-slate-700"
                                  )}>
                                    <MapPin size={18} className={isMedical ? "text-red-400" : "text-slate-400"} />
                                  </div>
                                  <div>
                                    <span className="text-sm font-bold text-slate-100 block">{link.title}</span>
                                    <span className="text-[10px] text-slate-500 uppercase tracking-widest">
                                      {isMedical ? "Emergency Facility" : "Nearby Facility"}
                                    </span>
                                  </div>
                                  <ExternalLink size={14} className={cn(
                                    "ml-auto transition-colors",
                                    isMedical ? "text-slate-500 group-hover:text-red-400" : "text-slate-600 group-hover:text-slate-400"
                                  )} />
                                </a>
                              );
                            })
                          ) : (
                            <div className="py-4 text-center text-slate-500 italic text-xs border border-dashed border-slate-700 rounded-2xl">
                              Searching for nearest medical facilities...
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Agent B: Forensic Vehicle Analysis Highlight */}
                    {analysisResult.toLowerCase().includes('plate') && (
                      <div className="p-4 bg-cyan-500/10 border border-cyan-500/20 rounded-2xl">
                        <div className="flex items-center gap-2 text-cyan-400 mb-3">
                          <Shield size={18} />
                          <h4 className="text-sm font-bold uppercase tracking-widest">Agent B: Forensic Analysis</h4>
                        </div>
                        <p className="text-xs text-slate-300">Vehicle metadata extracted and synced to Officer Command Feed.</p>
                      </div>
                    )}
                    
                    {groundingLinks.length > 0 && (
                      <div className="mt-6 pt-6 border-t border-slate-800">
                        <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Nearby Services & Resources</h4>
                        <div className="grid grid-cols-1 gap-3">
                          {groundingLinks.map((link, idx) => (
                            <a 
                              key={idx}
                              href={link.uri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-3 p-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl border border-slate-700/50 transition-colors group"
                            >
                              <div className="w-8 h-8 bg-cyan-500/10 rounded-lg flex items-center justify-center group-hover:bg-cyan-500/20">
                                <MapPin size={16} className="text-cyan-400" />
                              </div>
                              <span className="text-sm font-medium text-slate-200">{link.title}</span>
                              <ExternalLink size={14} className="ml-auto text-slate-500" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-slate-500 py-20">
                    <ShieldAlert size={48} className="mb-4 opacity-20" />
                    <p>Waiting for data input...</p>
                    <p className="text-xs mt-2">Upload an image to trigger agents in {location.name}</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-10">
            <div className="lg:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl p-8">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-xl font-bold">Activity Map: {location.name}</h3>
                <div className="flex gap-2">
                  <span className="flex items-center gap-1.5 text-xs text-slate-400">
                    <div className="w-2 h-2 bg-cyan-500 rounded-full"></div> Traffic
                  </span>
                  <span className="flex items-center gap-1.5 text-xs text-slate-400">
                    <div className="w-2 h-2 bg-amber-500 rounded-full"></div> Hazards
                  </span>
                </div>
              </div>
              <div className="aspect-[21/9] bg-slate-800 rounded-2xl relative overflow-hidden border border-slate-700/50">
                <img 
                  src={`https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&q=80&w=1200&sig=${location.name}`} 
                  alt="City Map" 
                  className="w-full h-full object-cover opacity-40 grayscale"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent"></div>
                
                {/* Real-time Map Markers */}
                <AnimatePresence>
                  {markers.map((m) => (
                    <motion.div 
                      key={m.id}
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0, opacity: 0 }}
                      className="absolute"
                      style={{ left: `${m.x}%`, top: `${m.y}%` }}
                    >
                      <div className="relative group">
                        <motion.div 
                          className={cn(
                            "w-4 h-4 rounded-full shadow-lg",
                            m.type === 'traffic' ? "bg-cyan-500 shadow-cyan-500/50" : 
                            m.type === 'hazard' ? "bg-amber-500 shadow-amber-500/50" : 
                            "bg-red-500 shadow-red-500/50"
                          )}
                          animate={{ scale: [1, 1.3, 1] }}
                          transition={{ repeat: Infinity, duration: 2 }}
                        />
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-slate-900 border border-slate-800 rounded text-[10px] font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                          {m.label}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>

            <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8">
              <h3 className="text-xl font-bold mb-6">Alerts for {location.name}</h3>
              <div className="space-y-4">
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl">
                  <div className="flex items-center gap-3 mb-2 text-red-400">
                    <ShieldAlert size={18} />
                    <span className="text-sm font-bold">EMERGENCY PROTOCOL</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed mb-3">
                    Critical incident detected in {location.name}. Emergency Response Agent has alerted local authorities.
                  </p>
                  <button className="text-[10px] font-bold text-red-400 hover:underline">VIEW INCIDENT DATA</button>
                </div>
                
                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl">
                  <div className="flex items-center gap-3 mb-2 text-amber-400">
                    <AlertTriangle size={18} />
                    <span className="text-sm font-bold">URBAN MAINTENANCE</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Infrastructure or cleanliness issue reported in {location.name}. Maintenance ticket generated.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'officer' && (
          <motion.div 
            key="officer"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold flex items-center gap-3">
                  <ShieldAlert className="text-cyan-400" size={28} />
                  Officer Intelligence Feed
                </h3>
                <div className="px-4 py-2 bg-cyan-500/10 text-cyan-400 text-xs font-bold rounded-full border border-cyan-500/20">
                  {tickets.length} ACTIVE REPORTS
                </div>
              </div>

              <div className="grid gap-4">
                {tickets.length === 0 ? (
                  <div className="text-center py-20 bg-slate-800/20 rounded-3xl border border-dashed border-slate-700">
                    <p className="text-slate-500">No active reports in the city intelligence feed.</p>
                  </div>
                ) : (
                  tickets.map((t) => (
                    <motion.div 
                      key={t.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="p-6 bg-slate-800/40 rounded-3xl border border-slate-700/50 hover:border-cyan-500/30 transition-all group"
                    >
                      <div className="flex flex-col md:flex-row md:items-center gap-6">
                        <div className={cn(
                          "w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 shadow-lg",
                          t.category === 'Accident' ? "bg-red-500/20 text-red-400 shadow-red-500/10" :
                          t.category === 'Traffic Violation' ? "bg-amber-500/20 text-amber-400 shadow-amber-500/10" :
                          t.category === 'Pothole' ? "bg-orange-500/20 text-orange-400 shadow-orange-500/10" :
                          "bg-emerald-500/20 text-emerald-400 shadow-emerald-500/10"
                        )}>
                          {t.category === 'Accident' ? <AlertTriangle size={32} /> :
                           t.category === 'Traffic Violation' ? <Shield size={32} /> :
                           t.category === 'Pothole' ? <AlertTriangle size={32} /> :
                           <Trash2 size={32} />}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className={cn(
                              "text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-md",
                              t.category === 'Accident' ? "bg-red-500/20 text-red-400" :
                              t.category === 'Traffic Violation' ? "bg-amber-500/20 text-amber-400" :
                              t.category === 'Pothole' ? "bg-orange-500/20 text-orange-400" :
                              "bg-slate-700 text-slate-400"
                            )}>
                              {t.category}
                            </span>
                            <span className="text-xs text-slate-500 font-mono">
                              {new Date(t.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                          
                          <h4 className="text-lg font-bold text-slate-100 mb-1">
                            {user?.role === 'Police Officer' 
                              ? (
                                <div className="flex flex-col gap-1">
                                  <span className="text-cyan-400">LOCATION: {t.location.name || location.name}</span>
                                  <span className="text-xs text-slate-400">REPORTER: {t.reporterName || 'Anonymous'}</span>
                                  {t.numberPlate && t.numberPlate !== 'Not detected' && (
                                    <span className="text-amber-400">PLATE: {t.numberPlate}</span>
                                  )}
                                </div>
                              )
                              : `${t.reporterName || 'Anonymous User'} reported an ${t.category?.toLowerCase() || 'incident'} in ${t.location.name || location.name}`
                            }
                          </h4>
                          <p className="text-sm text-slate-400 line-clamp-3 italic mb-4">
                            "{t.description || 'No description provided.'}"
                          </p>

                          {t.analysisResult && (
                            <div className={cn(
                              "mt-4 p-4 border rounded-2xl",
                              t.category === 'Accident' ? "bg-red-500/5 border-red-500/10" : "bg-cyan-500/5 border-cyan-500/10"
                            )}>
                              <div className={cn(
                                "flex items-center gap-2 mb-2",
                                t.category === 'Accident' ? "text-red-400" : "text-cyan-400"
                              )}>
                                <ShieldAlert size={16} />
                                <span className="text-[10px] font-bold uppercase tracking-widest">AI Intelligence Analysis</span>
                              </div>
                              <div className="prose prose-invert prose-xs max-w-none text-slate-300">
                                <ReactMarkdown>{t.analysisResult}</ReactMarkdown>
                              </div>
                              
                              {t.groundingLinks && t.groundingLinks.length > 0 && (
                                <div className="mt-4 pt-4 border-t border-slate-700/50">
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Nearby Facilities (Grounding)</span>
                                  <div className="flex flex-wrap gap-2">
                                    {t.groundingLinks.map((link, idx) => (
                                      <a 
                                        key={idx}
                                        href={link.uri}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="inline-flex items-center gap-1.5 px-2 py-1 bg-slate-950 border border-slate-800 rounded-lg text-[10px] text-cyan-400 hover:bg-slate-900 transition-colors"
                                      >
                                        <Globe size={12} />
                                        {link.title}
                                        <ExternalLink size={10} />
                                      </a>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}

                          {t.visualData && (
                            <div className="mt-4 rounded-2xl overflow-hidden border border-slate-700 max-w-md shadow-2xl">
                              <div className="bg-slate-900 px-4 py-2 border-b border-slate-700 flex justify-between items-center">
                                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Evidence Image</span>
                                <span className="text-[10px] font-mono text-slate-500">{t.id}</span>
                              </div>
                              <img 
                                src={getImageSrc(t.visualData)} 
                                alt="Report Visual" 
                                className="w-full h-auto object-cover max-h-96 cursor-pointer hover:opacity-90 transition-opacity"
                                referrerPolicy="no-referrer"
                                onClick={() => setSelectedImage(t.visualData || null)}
                              />
                              <div className="bg-slate-900 px-4 py-2 border-t border-slate-700 text-center">
                                <button 
                                  onClick={() => setSelectedImage(t.visualData || null)}
                                  className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest hover:text-cyan-300 transition-colors"
                                >
                                  View Full Resolution Image
                                </button>
                              </div>
                            </div>
                          )}
                          
                          {(t.numberPlate && t.numberPlate !== 'Not detected' || t.vehicleDetails) && (
                            <div className="mt-4 space-y-3">
                              <div className="flex flex-wrap gap-3">
                                {t.numberPlate && t.numberPlate !== 'Not detected' && (
                                  <div className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-xl flex items-center gap-3">
                                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Vehicle Plate</span>
                                    <span className="text-sm font-mono font-bold text-cyan-400 tracking-wider">
                                      {t.numberPlate}
                                    </span>
                                  </div>
                                )}
                                {t.vehicleDetails && (
                                  <>
                                    {t.vehicleDetails.brand && (
                                      <div className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-xl flex items-center gap-3">
                                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Brand</span>
                                        <span className="text-xs font-bold text-slate-300">{t.vehicleDetails.brand}</span>
                                      </div>
                                    )}
                                    {t.vehicleDetails.model && (
                                      <div className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-xl flex items-center gap-3">
                                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Model</span>
                                        <span className="text-xs font-bold text-slate-300">{t.vehicleDetails.model}</span>
                                      </div>
                                    )}
                                    {t.vehicleDetails.color && (
                                      <div className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-xl flex items-center gap-3">
                                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Color</span>
                                        <span className="text-xs font-bold text-slate-300">{t.vehicleDetails.color}</span>
                                      </div>
                                    )}
                                  </>
                                )}
                              </div>
                              <button className="text-[10px] font-bold text-cyan-500 hover:underline">RUN FORENSIC DATABASE CHECK</button>
                            </div>
                          )}
                        </div>

                        <div className="flex flex-col items-end gap-3">
                          <div className={cn(
                            "px-3 py-1 rounded-full text-[10px] font-bold border",
                            t.status === 'Pending' ? "bg-amber-500/10 text-amber-400 border-amber-500/20" :
                            t.status === 'In Progress' ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/20" :
                            "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                          )}>
                            {t.status.toUpperCase()}
                          </div>
                          {t.status !== 'Resolved' && (
                            <div className="flex flex-col gap-2 w-full md:w-48">
                              <div className="relative">
                                <input 
                                  type="number" 
                                  placeholder="Reward Points"
                                  className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                                  id={`reward-${t.id}`}
                                />
                              </div>
                              <div className="flex gap-2">
                                <button 
                                  onClick={() => {
                                    const input = document.getElementById(`reward-${t.id}`) as HTMLInputElement;
                                    const val = parseInt(input?.value) || 50;
                                    handleOfficerAction(t.id, 'validate', val);
                                  }}
                                  className="flex-1 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold rounded-xl transition-colors"
                                >
                                  APPROVE & REWARD
                                </button>
                                <button 
                                  onClick={() => handleOfficerAction(t.id, 'dispatch')}
                                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white text-[10px] font-bold rounded-xl transition-colors"
                                >
                                  DISPATCH
                                </button>
                              </div>
                            </div>
                          )}
                          
                          {t.status === 'Resolved' && t.rewardAmount && (
                            <div className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-lg border border-emerald-500/20">
                              REWARDED: {t.rewardAmount} PTS
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
                <h4 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-4">Quick Actions</h4>
                <div className="space-y-3">
                  <button 
                    onClick={handleBroadcastAlert}
                    className="w-full p-4 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded-2xl text-red-400 text-sm font-bold transition-all text-left flex items-center justify-between"
                  >
                    Broadcast Emergency Alert
                    <AlertTriangle size={16} />
                  </button>
                  <button 
                    onClick={handleUpdateSignals}
                    className="w-full p-4 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/20 rounded-2xl text-cyan-400 text-sm font-bold transition-all text-left flex items-center justify-between"
                  >
                    Update Signal Patterns
                    <Activity size={16} />
                  </button>
                </div>
              </div>
              
              <div className="md:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
                <h4 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-4">Officer Performance</h4>
                <div className="flex items-center gap-8">
                  <div className="flex-1">
                    <div className="flex justify-between mb-2">
                      <span className="text-xs text-slate-400">Response Rate</span>
                      <span className="text-xs font-bold text-emerald-400">94%</span>
                    </div>
                    <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 w-[94%]" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between mb-2">
                      <span className="text-xs text-slate-400">Resolution Time</span>
                      <span className="text-xs font-bold text-cyan-400">12m avg</span>
                    </div>
                    <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-cyan-500 w-[75%]" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
        {activeTab === 'patrol' && (
          <motion.div 
            key="patrol"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold flex items-center gap-3">
                  <ShieldCheck className="text-cyan-400" size={28} />
                  Patrol Management & Deployment
                </h3>
                <div className="px-4 py-2 bg-cyan-500/10 text-cyan-400 text-xs font-bold rounded-full border border-cyan-500/20 uppercase tracking-widest">
                  Active Deployment Mode
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="p-6 bg-slate-800/40 rounded-3xl border border-slate-700/50">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Active Patrols</p>
                  <p className="text-3xl font-bold text-slate-100">12</p>
                  <p className="text-[10px] text-emerald-400 mt-1 font-bold">+2 from last hour</p>
                </div>
                <div className="p-6 bg-slate-800/40 rounded-3xl border border-slate-700/50">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Avg Response Time</p>
                  <p className="text-3xl font-bold text-slate-100">4.2m</p>
                  <p className="text-[10px] text-cyan-400 mt-1 font-bold">-1.5m optimization</p>
                </div>
                <div className="p-6 bg-slate-800/40 rounded-3xl border border-slate-700/50">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">High-Risk Zones</p>
                  <p className="text-3xl font-bold text-slate-100">3</p>
                  <p className="text-[10px] text-amber-400 mt-1 font-bold">Patrols dispatched</p>
                </div>
              </div>

              <div className="bg-slate-950/50 rounded-3xl border border-slate-800 p-6">
                <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Patrol Unit Status</h4>
                <div className="space-y-4">
                  {[
                    { id: 'UNIT-101', officer: 'Officer Vikram', location: 'Marine Drive', status: 'On Patrol', battery: '84%' },
                    { id: 'UNIT-204', officer: 'Officer Sneha', location: 'Connaught Place', status: 'Responding', battery: '62%' },
                    { id: 'UNIT-305', officer: 'Officer Rajesh', location: 'Indiranagar', status: 'On Patrol', battery: '91%' },
                    { id: 'UNIT-412', officer: 'Officer Arjun', location: 'Banjara Hills', status: 'Standby', battery: '100%' }
                  ].map((unit, idx) => (
                    <div key={idx} className="flex items-center justify-between p-4 bg-slate-900/50 rounded-2xl border border-slate-800 hover:border-cyan-500/30 transition-all">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center">
                          <Shield size={20} className="text-cyan-400" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-100">{unit.id} - {unit.officer}</p>
                          <p className="text-[10px] text-slate-500">{unit.location}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <p className={cn(
                            "text-[10px] font-bold uppercase tracking-widest",
                            unit.status === 'Responding' ? "text-amber-400" : "text-emerald-400"
                          )}>{unit.status}</p>
                          <p className="text-[10px] text-slate-500">Battery: {unit.battery}</p>
                        </div>
                        <button 
                          onClick={() => setActiveCommsUnit(unit)}
                          className="px-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-[10px] font-bold text-cyan-400 rounded-lg transition-colors border border-cyan-500/20"
                        >
                          COMMS
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </main>

      {/* Comms Modal */}
      <AnimatePresence>
        {activeCommsUnit && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md"
            onClick={() => setActiveCommsUnit(null)}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-3xl overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-cyan-500/10 rounded-xl flex items-center justify-center">
                    <Shield size={20} className="text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-100">{activeCommsUnit.id}</h3>
                    <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Secure Channel Alpha</p>
                  </div>
                </div>
                <button 
                  onClick={() => setActiveCommsUnit(null)}
                  className="w-8 h-8 flex items-center justify-center text-slate-500 hover:text-white transition-colors"
                >
                  <LogOut size={18} className="rotate-90" />
                </button>
              </div>

              <div className="h-80 overflow-y-auto p-6 space-y-4 bg-slate-950/30">
                {commsLog.filter(l => l.unitId === activeCommsUnit.id).length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-slate-600 italic text-xs">
                    <Navigation size={24} className="mb-2 opacity-20" />
                    <p>No active transmissions.</p>
                  </div>
                ) : (
                  commsLog.filter(l => l.unitId === activeCommsUnit.id).map((log, i) => (
                    <div key={i} className={cn(
                      "flex flex-col max-w-[80%]",
                      log.type === 'sent' ? "ml-auto items-end" : "mr-auto items-start"
                    )}>
                      <div className={cn(
                        "px-4 py-2 rounded-2xl text-sm",
                        log.type === 'sent' 
                          ? "bg-cyan-600 text-white rounded-tr-none" 
                          : "bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700"
                      )}>
                        {log.message}
                      </div>
                      <span className="text-[8px] text-slate-500 mt-1 font-mono uppercase">{log.time}</span>
                    </div>
                  ))
                )}
              </div>

              <div className="p-6 bg-slate-900 border-t border-slate-800">
                <div className="flex gap-2">
                  <input 
                    type="text"
                    value={commsMessage}
                    onChange={(e) => setCommsMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type dispatch message..."
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
                  />
                  <button 
                    onClick={handleSendMessage}
                    disabled={!commsMessage.trim()}
                    className="w-10 h-10 bg-cyan-500 text-slate-950 rounded-xl flex items-center justify-center hover:bg-cyan-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Navigation size={18} className="rotate-90" />
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global Notification */}
      <AnimatePresence>
        {showNotification && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[200] w-full max-w-md px-4"
          >
            <div className={cn(
              "p-4 rounded-2xl border shadow-2xl flex items-center gap-4",
              showNotification.type === 'success' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" :
              showNotification.type === 'warning' ? "bg-amber-500/10 border-amber-500/20 text-amber-400" :
              "bg-cyan-500/10 border-cyan-500/20 text-cyan-400"
            )}>
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                showNotification.type === 'success' ? "bg-emerald-500/20" :
                showNotification.type === 'warning' ? "bg-amber-500/20" :
                "bg-cyan-500/20"
              )}>
                {showNotification.type === 'success' ? <CheckCircle2 size={20} /> :
                 showNotification.type === 'warning' ? <AlertTriangle size={20} /> :
                 <Activity size={20} />}
              </div>
              <p className="text-sm font-bold leading-tight">{showNotification.message}</p>
              <button 
                onClick={() => setShowNotification(null)}
                className="ml-auto text-slate-500 hover:text-white transition-colors"
              >
                <LogOut size={16} className="rotate-90" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Image Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative max-w-5xl w-full max-h-[90vh] rounded-3xl overflow-hidden shadow-2xl border border-slate-800"
              onClick={(e) => e.stopPropagation()}
            >
              <button 
                onClick={() => setSelectedImage(null)}
                className="absolute top-4 right-4 w-10 h-10 bg-slate-900/80 backdrop-blur-md rounded-full flex items-center justify-center text-slate-400 hover:text-white transition-colors z-10"
              >
                <LogOut size={20} className="rotate-90" />
              </button>
              <img 
                src={getImageSrc(selectedImage)} 
                alt="Full Resolution Evidence" 
                className="w-full h-full object-contain bg-slate-950"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group w-full text-left",
        active 
          ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20" 
          : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
      )}
    >
      <span className={cn("transition-transform duration-200", active ? "scale-110" : "group-hover:scale-110")}>
        {icon}
      </span>
      <span className="font-medium">{label}</span>
      {active && (
        <motion.div 
          layoutId="active-pill"
          className="ml-auto w-1.5 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_8px_rgba(34,211,238,0.8)]"
        />
      )}
    </button>
  );
}

function StatCard({ title, value, unit, icon, trend, color }: { 
  title: string, 
  value: string | number, 
  unit: string, 
  icon: React.ReactNode, 
  trend: string,
  color: 'emerald' | 'amber' | 'cyan' | 'indigo'
}) {
  const colorMap = {
    emerald: "bg-emerald-500/10 border-emerald-500/20",
    amber: "bg-amber-500/10 border-amber-500/20",
    cyan: "bg-cyan-500/10 border-cyan-500/20",
    indigo: "bg-indigo-500/10 border-indigo-500/20"
  };

  return (
    <div className={cn("p-6 rounded-3xl border", colorMap[color])}>
      <div className="flex justify-between items-start mb-4">
        <div className="p-2.5 bg-slate-950/50 rounded-xl border border-slate-800">
          {icon}
        </div>
        <TrendingUp size={16} className="text-slate-500" />
      </div>
      <div>
        <p className="text-xs text-slate-400 font-medium mb-1 uppercase tracking-wider">{title}</p>
        <div className="flex items-baseline gap-1 mb-2">
          <span className="text-3xl font-bold tracking-tight">{value}</span>
          <span className="text-xs text-slate-500 font-medium">{unit}</span>
        </div>
        <p className="text-[10px] text-slate-500 font-medium">{trend}</p>
      </div>
    </div>
  );
}

function ShieldCheckIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <ShieldCheck {...props} />
  );
}
