export interface CityStats {
  safetyScore: number;
  activeAlerts: number;
  trafficDensity: 'Low' | 'Medium' | 'High';
  rewardPoints: number;
}

export interface MaintenanceTicket {
  id: string;
  type: string;
  category: string;
  status: 'Pending' | 'In Progress' | 'Resolved';
  location: { lat: number; lng: number; name?: string };
  lat?: number;
  lng?: number;
  timestamp: string;
  reporterName?: string;
  description?: string;
  visualData?: string;
  numberPlate?: string;
  vehicleDetails?: {
    brand?: string;
    model?: string;
    color?: string;
  };
  rewardAmount?: number;
  reporterUid?: string;
  createdAt?: string;
  analysisResult?: string;
  groundingLinks?: { uri: string; title: string }[];
}

export interface TrafficSignal {
  lane: string;
  vehicleCount: number;
  greenDuration: number;
}

export interface MapMarker {
  id: string;
  type: 'traffic' | 'hazard' | 'accident';
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  label: string;
}
