import { GoogleGenAI, GenerateContentResponse, FunctionDeclaration, Type } from "@google/genai";

const SYSTEM_PROMPT = `System Instruction: UrbanPulse AI Modular Controller (V3.1)
Role: You are the UrbanPulse AI Orchestrator. Your primary goal is to act as the intelligent bridge between Citizens, Police Officers, and Admin/Infrastructure.

1. Access Control Logic
User Mode: Receives citizen inputs (Location, Description, Image).
Officer Mode: Provides a "Command Feed" where officers view evidence and manually assign rewards.
Admin Mode: Manages the system-wide "Safety Scores" and hospital databases.

2. Specialized Agent Blocks
Agent A: Emergency & Medical Logistics (Hospital Mapping)
Input: User's specified location (e.g., "Hebbal, Mysuru").
Action: Identify the accident severity and type.
Database Lookup: You MUST use the googleMaps tool to find at least 3 nearest hospitals relative to the EXACT location provided by the user.
User Output Requirements: 
- DO NOT say "Analysis completed".
- MANDATORY: Provide a "COMPLETE INCIDENT DESCRIPTION" covering vehicle types, damage, and potential injuries.
- MANDATORY: Provide a "VEHICLE METADATA" section with Number Plate, Brand, Model, and Color.
- MANDATORY: Provide a "NEAREST HOSPITALS" section. You MUST list the names and distances of at least 3 hospitals you found via the tool directly in your text response. This is the most critical part of the report. If you do not include these, the report is incomplete.
- Example: "Help is on the way. [Complete Incident Description]. VEHICLE METADATA: [Plate: KA-01-XX-1234, Brand: Toyota, Model: Fortuner, Color: White]. NEAREST HOSPITALS: [Hospital A - 2km], [Hospital B - 4km], [Hospital C - 5km]. Emergency report sent."

Agent B: Forensic Vehicle Analysis (Officer Data)
Input: High-resolution image of a traffic violation or accident.
Task: Extract metadata from the visual input.
Output Format (MANDATORY for parsing):
Number Plate: [Detected License String or 'Not detected']
Brand: [Brand Name or 'Unknown']
Model: [Model Name or 'Unknown']
Color: [Vehicle Color or 'Unknown']
Action: This metadata is synced directly to the Officer Feed.

Agent C: Traffic Violation & Compliance Agent
Input: Image/Video of non-helmet riding or congestion.
Output Requirements:
- DO NOT say "Analysis completed".
- Generate a "COMPLETE VIOLATION DESCRIPTION".
- Format: "Violation: [Type]. Location: [Input Location]. Time: [System Time]. Vehicle: [Model Name]. [Detailed Description of the event]."
- NOTE: Only search for hospitals if specifically requested or if there is an injury involved. Otherwise, focus on the violation details.

Agent D: Manual Reward & Officer Feed Agent
Task: Fix the "Officer Feed" by ensuring real-time updates.
Logic: 1. User uploads evidence -> System generates a "Pending Case".
2. Officer views the exact image, Location, and Vehicle Details from Agent B.
3. Officer Decision: The Officer manually inputs a reward value.

3. Operational Guidelines
- Officer Verification: The AI identifies the violation, but the Police Officer has the final authority.
- Data Privacy: Encrypt number plate data and ensure it is only visible to the Officer Login.
- Output Quality: Always provide a "COMPLETE DESCRIPTION" of the scene. Never use generic success messages.
- Grounding: When using Google Maps, you MUST list the hospital names and their relative distance in the text output.`;

const sendEmergencyEmailDeclaration: FunctionDeclaration = {
  name: "send_emergency_email",
  description: "Sends an emergency email to the Police and Hospital for an accident report.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      location: {
        type: Type.STRING,
        description: "The specific location of the accident."
      },
      description: {
        type: Type.STRING,
        description: "A detailed description of the accident."
      },
      severity: {
        type: Type.STRING,
        description: "The severity of the accident (e.g., Critical, Major, Minor)."
      },
      numberPlate: {
        type: Type.STRING,
        description: "The number plate of the vehicle(s) involved, if visible."
      }
    },
    required: ["location", "description", "severity"]
  }
};

export class GeminiService {
  private getAI() {
    const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("Gemini API key is not set. Please check your environment variables or select an API key.");
    }
    return new GoogleGenAI({ apiKey });
  }

  async analyzeUrbanData(input: string | { mimeType: string; data: string }, prompt: string = "Analyze this urban data and provide insights based on your specialized agents.", userLocation?: { lat: number; lng: number }) {
    const ai = this.getAI();
    const parts: any[] = [];
    
    if (typeof input === 'string') {
      parts.push({ text: input });
    } else {
      parts.push({
        inlineData: {
          mimeType: input.mimeType,
          data: input.data
        }
      });
    }
    
    parts.push({ text: prompt });

    const config: any = {
      systemInstruction: SYSTEM_PROMPT,
      temperature: 0.7,
      tools: [
        { googleMaps: {} },
        { functionDeclarations: [sendEmergencyEmailDeclaration] }
      ],
      toolConfig: { 
        includeServerSideToolInvocations: true,
        retrievalConfig: userLocation ? {
          latLng: {
            latitude: userLocation.lat,
            longitude: userLocation.lng
          }
        } : undefined
      }
    };

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: { parts },
      config
    });

    return response;
  }

  async findNearbyHospitals(locationName: string, coords: { lat: number; lng: number }) {
    const ai = this.getAI();
    const prompt = `Find at least 3 nearest hospitals near ${locationName} (${coords.lat}, ${coords.lng}). 
    You MUST use the googleMaps tool. 
    Provide their names, distances, and contact info if available.`;

    const config: any = {
      systemInstruction: SYSTEM_PROMPT,
      temperature: 0.7,
      tools: [{ googleMaps: {} }],
      toolConfig: {
        includeServerSideToolInvocations: true,
        retrievalConfig: {
          latLng: {
            latitude: coords.lat,
            longitude: coords.lng
          }
        }
      }
    };

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config
    });

    return response;
  }

  async getRealTimeTrafficIntel(locationName: string, coords?: { lat: number; lng: number }) {
    const ai = this.getAI();
    const prompt = `Fetch real-time traffic intelligence for ${locationName}. 
    Include:
    - Current congestion levels
    - Peak Traffic Zones (areas with highest congestion)
    - Low Traffic Zones (areas with minimal congestion)
    - Any active road closures or accidents
    - Estimated travel times to key landmarks
    - AI-driven signal optimization suggestions based on current flow.`;

    const config: any = {
      systemInstruction: SYSTEM_PROMPT,
      temperature: 0.7,
      tools: [{ googleSearch: {} }]
    };

    if (coords) {
      config.toolConfig = {
        retrievalConfig: {
          latLng: {
            latitude: coords.lat,
            longitude: coords.lng
          }
        }
      };
    }

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config
    });

    return response.text;
  }
}

export const geminiService = new GeminiService();
